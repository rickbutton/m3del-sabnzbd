m3del-sabnzbd
=============

My sabnzbd puppet module. Tested only in Ubuntu
