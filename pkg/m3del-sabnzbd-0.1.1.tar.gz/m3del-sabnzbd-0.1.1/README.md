m3del-sabnzbd
=============

A puppet module used to maintain a sabnzbd instance.

How to use
==========

Make sure to look over the *params.pp* manifest and make necessary changes.
This does have a dependancy of the puppetlabs/apt module to add the correct repo to ubuntu.

**include sabnzbd**


Tested Platforms
================

Ubuntu
